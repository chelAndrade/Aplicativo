package com.example.pedro.bolsas;

import android.provider.BaseColumns;

public class BancoContractAutor {
    public static final String TEXT_TYPE = " TEXT";
    public static final String INT_TYPE = " INTEGER";
    public static final String SEP = ",";
    public static final String SQL_CREATE_AUTOR = "CREATE TABLE " + Autor.TABLE_NAME + " (" +
            Autor._ID + INT_TYPE +" PRIMARY KEY AUTOINCREMENT" + SEP +
            Autor.COLUMN_NAME_NOME + TEXT_TYPE +" UNIQUE " + SEP +
            Autor.COLUMN_NAME_TITULO + TEXT_TYPE + SEP +
            Autor.COLUMN_NAME_EDITORA + INT_TYPE + ")";
    public static final String SQL_DROP_AUTOR = "DROP TABLE IF EXISTS " + BancoContractAutor.Autor.TABLE_NAME;

    public BancoContractAutor(){}

    public static final class Autor implements BaseColumns {
        public static final String TABLE_NAME = "autor";
        public static final String COLUMN_NAME_NOME = "nome";
        public static final String COLUMN_NAME_TITULO = "titulo";
        public static final String COLUMN_NAME_EDITORA = "editora";

    }
}

