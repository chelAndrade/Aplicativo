package com.example.pedro.bolsas;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;


public class BancoAutor extends SQLiteOpenHelper{
    public static final int DATABASE_VERSION = 2;
    public static final String DATABASE_NAME = "Biblioteca.db";

    public BancoAutor (Context context){
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(BancoContractAutor.SQL_DROP_AUTOR);
        db.execSQL(BancoContractAutor.SQL_CREATE_AUTOR);
        }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }


    public Boolean salvar (AutorModel autor){
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(BancoContractAutor.Autor.COLUMN_NAME_NOME, autor.getNome());
        values.put(BancoContractAutor.Autor.COLUMN_NAME_TITULO, autor.getTitulo());
        values.put(BancoContractAutor.Autor.COLUMN_NAME_EDITORA, autor.getEditora());
        db.insert(BancoContractAutor.Autor.TABLE_NAME, null, values);
        return true;
    }
    public Cursor atualizaAutores(){
        try {
            SQLiteDatabase db = this.getReadableDatabase();
            String[] visao = {
                    BancoContractAutor.Autor._ID,
                    BancoContractAutor.Autor.COLUMN_NAME_NOME,
                    BancoContractAutor.Autor.COLUMN_NAME_TITULO,
                    BancoContractAutor.Autor.COLUMN_NAME_EDITORA


            };

            Cursor c = db.query(BancoContract.Livro.TABLE_NAME, visao, null, null, null, null, null);
            return c;

        } catch (Exception e) {
            Log.e("BIBLIO", e.getLocalizedMessage());
            Log.e("BIBLIO", e.getStackTrace().toString());
            return null;
        }
    }

    public AutorModel getAutor(int i) {
        SQLiteDatabase db = this.getReadableDatabase();
        try {
            String[] visao = {
                    BancoContractAutor.Autor._ID,
                    BancoContractAutor.Autor.COLUMN_NAME_NOME,
                    BancoContractAutor.Autor.COLUMN_NAME_TITULO,
                    BancoContractAutor.Autor.COLUMN_NAME_EDITORA
            };
            String sel = BancoContractAutor.Autor._ID + "=?";
            String arg[] = {Integer.toString(i)};
            Cursor c = db.query(BancoContractAutor.Autor.TABLE_NAME, visao, sel, arg, null, null, null);
            c.moveToFirst();
            AutorModel autor = new AutorModel(c.getString(c.getColumnIndex(BancoContract.Livro.COLUMN_NAME_TITULO)),
                    c.getString(c.getColumnIndex(BancoContractAutor.Autor.COLUMN_NAME_TITULO)), c.getString(
                    c.getColumnIndex(BancoContractAutor.Autor.COLUMN_NAME_EDITORA)));
            return autor;

        } catch (Exception e) {
            Log.e("BIBLIO", e.getLocalizedMessage());
            Log.e("BIBLIO", e.getStackTrace().toString());
            return null;
        }
    }
    public void deletar (int i){
        String onde = BancoContractAutor.Autor._ID + "="+i;
        SQLiteDatabase db = this.getReadableDatabase();
        db.delete(BancoContractAutor.Autor.TABLE_NAME,onde,null);
        db.close();
    }
    public void editar(AutorModel autor, int i ){
        SQLiteDatabase db = this.getReadableDatabase();
        ContentValues values = new ContentValues();
        values.put(BancoContractAutor.Autor.COLUMN_NAME_NOME, autor.getNome());
        values.put(BancoContractAutor.Autor.COLUMN_NAME_TITULO, autor.getTitulo());
        values.put(BancoContractAutor.Autor.COLUMN_NAME_EDITORA, autor.getEditora());
        Log.i("titulo",autor.getTitulo());
        String sel = BancoContract.Livro._ID + "=?";
        String arg[] = {Integer.toString(i)};
        try {
            db.update(BancoContract.Livro.TABLE_NAME, values, sel, arg);
        }catch (Exception e){
            Log.e("ERRO",e.getMessage());
        }
    }
}

