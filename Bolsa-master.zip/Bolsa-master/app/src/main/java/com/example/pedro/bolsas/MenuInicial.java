package com.example.pedro.bolsas;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MenuInicial extends AppCompatActivity {
    private Button listarLivros;
    private Button listarAutores;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_inicial);
        listarLivros = findViewById(R.id.btnListaLivros);

        listarLivros.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent listar = new Intent(MenuInicial.this,Listar.class);
                startActivity(listar);
            }
        });

        listarAutores = findViewById(R.id.btnListarAutores);
        listarAutores.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent listar = new Intent(MenuInicial.this,Listar.class);
                startActivity(listar);
            }
        });
    }


}
