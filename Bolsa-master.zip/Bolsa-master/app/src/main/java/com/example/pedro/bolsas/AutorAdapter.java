package com.example.pedro.bolsas;

import android.content.Context;
import android.database.Cursor;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CursorAdapter;
import android.widget.TextView;

public class AutorAdapter extends CursorAdapter {
    private  BancoAutor db;
    public AutorAdapter(Context context, Cursor c) {
        super(context, c, 0);
        db = new BancoAutor(context);
    }
    @Override
    public View newView(Context context, Cursor cursor, ViewGroup parent) {
        return LayoutInflater.from(context).inflate(R.layout.listar_livro,parent,false);
    }
    @Override
    public void bindView(View view, Context context, Cursor cursor) {
        TextView txtAutor = (TextView)view.findViewById(R.id.Autor);



        String autor = cursor.getString(cursor.getColumnIndexOrThrow(BancoContractAutor.Autor.COLUMN_NAME_TITULO));

        txtAutor.setText(autor);

    }
    public void atualizaAutores(){

        this.changeCursor(db.atualizaAutores());
    }
    public AutorModel getAutor (int i ) {
        return  db.getAutor(i);
    }

}


